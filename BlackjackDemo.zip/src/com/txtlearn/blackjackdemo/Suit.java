package com.txtlearn.blackjackdemo;

public enum Suit {
    CLUB, DIAMOND, SPADE, HEART

}
